import requests

url = "https://language-translation.p.rapidapi.com/translateLanguage/detect-language"

querystring = {"text":"Привет, мой дорогой друг!"}

headers = {
    'x-rapidapi-key': "316e0c1e78msh93c2b3ee1c00d5dp1ca074jsn1bdf0d561f9a",
    'x-rapidapi-host': "language-translation.p.rapidapi.com"
    }

response = requests.request("GET", url, headers=headers, params=querystring)

print(response.text)







